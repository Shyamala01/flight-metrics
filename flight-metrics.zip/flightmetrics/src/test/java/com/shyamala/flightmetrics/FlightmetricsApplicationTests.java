package com.shyamala.flightmetrics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightmetricsApplicationTests {

	@Test
	void contextLoads() {
	}

}
