package com.shyamala.flightmetrics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightmetricsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightmetricsApplication.class, args);
	}

}
